Crypto Edge Terminal V2
Open index.html in a browser. GitHub Pages entry file should be named index.html.
V2 adds clearer SL/TP/BE event history, candle timestamps, chart level lines, support/resistance cards, and a paper-mode badge.
No real trades are placed. Internet connection required.

Crypto Edge Terminal V2 - ALL COINS

Features:
- Dynamically loads Binance USDT spot trading pairs.
- Search any listed USDT coin.
- All USDT Coins / High Risk-Volatile filter.
- Scanner for 20/50/100 coins.
- BUY / SELL / WAIT based on the last CLOSED 5-minute candle.
- Entry, Stop Loss, TP1, TP2 using ATR 1.5 and RR 1.5 / 3.
- 24h change and volatility columns.
- Click Open to load a coin chart.
- Paper/signal mode only. This page does not place trades.

GitHub Pages:
Replace the repository root index.html with this file and commit to main.
Keep Pages source as main / (root).
